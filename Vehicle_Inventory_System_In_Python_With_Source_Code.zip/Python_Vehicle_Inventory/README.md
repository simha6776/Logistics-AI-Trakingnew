# Python_Vehicle_Inventory
Python script for simple vehicle inventory system.
This Python script was built for my ITS 320 Programming class. 
It allows the user to add and delete vehicles from inventory, view the inventory, update a vehicle 
in inventory, and export the current inventory to a text file. 
Other developers may find this simple script useful as a model of how to construct 
a simple inventory system within Python.
