# app.py
import os
import time
import threading
from datetime import datetime

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import cv2

from detector.yolo_detector import YOLODetector
from detector.tracker import TrackerWrapper
from detector.ocr import read_plate
from database import Session, events

app = Flask(__name__)
CORS(app)

MODEL_PATH = "yolov8n.pt"
DETECT_CONF = 0.4

CAMERA_LOCATIONS = {
    "cam1": "Bengaluru Hub A",
    "cam2": "Mysuru Warehouse",
    "cam3": "Chennai Sorting Center",
    "cam4": "Mumbai Distribution Point",
}

detector = YOLODetector(model_path=MODEL_PATH, conf=DETECT_CONF)
tracker = TrackerWrapper()
processing = {}

def ensure_upload_folder():
    os.makedirs('uploads', exist_ok=True)

def process_video(filepath, camera_id="cam1"):
    sess = Session()
    cap = cv2.VideoCapture(filepath)
    frame_no = 0
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame_no += 1
            dets = detector.detect(frame)
            sort_in = []
            for d in dets:
                name = d.get("class_name", "")
                if name.lower() in ["car","truck","bus","motorbike","bike","bicycle","van"]:
                    x,y,w,h = d["bbox"]
                    x1,y1,x2,y2 = x, y, x + w, y + h
                    score = d["conf"]
                    sort_in.append([x1,y1,x2,y2,score])
            trackers = tracker.update(sort_in)
            for t in trackers:
                x1,y1,x2,y2,tid = t
                w = x2 - x1
                h = y2 - y1
                cx1,cy1,cx2,cy2 = map(int, [x1,y1,x2,y2])
                plate = None
                if cx1 < cx2 and cy1 < cy2:
                    try:
                        crop = frame[max(0,cy1):cy2, max(0,cx1):cx2]
                        plate = read_plate(crop)
                    except Exception:
                        plate = ""
                location_name = CAMERA_LOCATIONS.get(camera_id, "Unknown Location")
                ins = events.insert().values(
                    object_id=str(int(tid)),
                    object_type="vehicle",
                    plate=plate,
                    camera_id=camera_id,
                    location=location_name,
                    timestamp=datetime.utcnow(),
                    frame=frame_no,
                    x=float(x1), y=float(y1), w=float(w), h=float(h)
                )
                try:
                    sess.execute(ins)
                except Exception:
                    pass
            sess.commit()
    finally:
        cap.release()
        sess.close()
        processing.pop(filepath, None)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    f = request.files.get('file')
    cam = request.form.get('camera_id', 'cam1')
    if not f:
        return jsonify({"error":"no file"}), 400
    ensure_upload_folder()
    path = os.path.join('uploads', f.filename)
    f.save(path)
    t = threading.Thread(target=process_video, args=(path, cam), daemon=True)
    t.start()
    processing[path] = {"thread": t, "camera": cam, "started": time.time()}
    return jsonify({"status":"processing", "path": path})

@app.route('/events/search', methods=['GET'])
def search_events():
    q_plate = request.args.get('plate')
    sess = Session()
    query = events.select()
    if q_plate:
        query = query.where(events.c.plate.like(f"%{q_plate}%"))
    res = sess.execute(query).fetchall()
    out = []
    for r in res:
        out.append({
            "id": r.id,
            "object_id": r.object_id,
            "object_type": r.object_type,
            "plate": r.plate,
            "camera_id": r.camera_id,
            "location": r.location,
            "timestamp": str(r.timestamp),
            "frame": r.frame,
            "bbox": {"x": r.x, "y": r.y, "w": r.w, "h": r.h}
        })
    sess.close()
    return jsonify(out)

@app.route('/location', methods=['GET'])
def get_location():
    plate = request.args.get('plate')
    if not plate:
        return jsonify({"error": "Plate number required"}), 400
    sess = Session()
    query = events.select().where(events.c.plate.like(f"%{plate}%")).order_by(events.c.timestamp.desc()).limit(1)
    result = sess.execute(query).fetchone()
    sess.close()
    if result:
        return jsonify({
            "plate": result.plate,
            "last_seen": str(result.timestamp),
            "location": result.location,
            "camera_id": result.camera_id
        })
    else:
        return jsonify({"message": "No record found for this plate"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
