# database.py
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, MetaData, Table
from sqlalchemy.orm import sessionmaker
from datetime import datetime

DB_URL = "sqlite:///logistics.db"
engine = create_engine(DB_URL, echo=False, connect_args={"check_same_thread": False})
metadata = MetaData()

events = Table('events', metadata,
    Column('id', Integer, primary_key=True),
    Column('object_id', String),
    Column('object_type', String),
    Column('plate', String, nullable=True),
    Column('camera_id', String, nullable=True),
    Column('location', String, nullable=True),
    Column('timestamp', DateTime, default=datetime.utcnow),
    Column('frame', Integer),
    Column('x', Float),
    Column('y', Float),
    Column('w', Float),
    Column('h', Float),
)

metadata.create_all(engine)
Session = sessionmaker(bind=engine)
