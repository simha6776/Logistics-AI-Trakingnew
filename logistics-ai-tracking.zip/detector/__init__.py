# detector package init
