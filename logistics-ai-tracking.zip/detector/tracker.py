# detector/tracker.py
import numpy as np
try:
    from sort import Sort
except Exception:
    raise

class TrackerWrapper:
    def __init__(self, max_age=30, min_hits=1):
        self.tracker = Sort(max_age=max_age, min_hits=min_hits)

    def update(self, detections):
        if len(detections) == 0:
            dets = np.empty((0,5))
        else:
            dets = np.array(detections)
        trackers = self.tracker.update(dets)
        return trackers
