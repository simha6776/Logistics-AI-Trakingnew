# detector/yolo_detector.py
from ultralytics import YOLO
import cv2

class YOLODetector:
    def __init__(self, model_path="yolov8n.pt", device=None, conf=0.4):
        # device None => auto (cpu or cuda if torch detects GPU)
        self.model = YOLO(model_path)
        self.conf = conf
        try:
            self.model.fuse()
        except Exception:
            pass
        self.class_names = self.model.names

    def detect(self, frame):
        # frame: numpy BGR image from cv2
        results = self.model(frame, imgsz=640, conf=self.conf, verbose=False)
        detections = []
        for res in results:
            boxes = getattr(res, 'boxes', None)
            if boxes is None:
                continue
            for box in boxes:
                cls = int(box.cls[0])
                conf = float(box.conf[0])
                x1,y1,x2,y2 = map(float, box.xyxy[0])
                w = x2 - x1; h = y2 - y1
                detections.append({
                    "class_id": cls,
                    "class_name": self.class_names.get(cls, str(cls)),
                    "conf": conf,
                    "bbox": [x1, y1, w, h]
                })
        return detections
